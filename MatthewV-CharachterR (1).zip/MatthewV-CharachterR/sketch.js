let Frame;
let Hair1;
let Hair2;
let Hair3;
let Eyes1;
let Eyes2;
let Eyes3;
let Clothes1;
let Clothes2;
let Clothes3;

let Hair_id;
let Eyes_id;
let Clothes_id;

function preload() {
  Frame = loadImage("Frame1.png");

  Hair1 =  loadImage("Hair1.png");
  Hair2 =  loadImage("Hair2.png");
  Hair3 =  loadImage("Hair3.png");

  Clothes1 = loadImage("Clothes1.png");
  Clothes2 = loadImage("Clothes2.png");
  Clothes3 = loadImage("Clothes3.png");
  Eyes1 = loadImage("Eyes1.png");
  Eyes2 = loadImage("Eyes2.png");
  Eyes3 = loadImage("Eyes3.png");
}

function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(220);

  if (Eyes_id == 1) {
    image(Eyes1, 0, 0)
  } else if (Eyes_id== 2) {
    image(Eyes2, 0, 0)
  } else if (Eyes_id == 3) { 
    image(Eyes3, 0, 0)
  }
  
  if (Hair_id == 1) {
    image(Hair1, 0, 0)
  } else if (Hair_id == 2) {
    image(Hair2, 0, 0)
  } else if (Hair_id == 3) {
    image(Hair3, 0, 0)
  }

  if (Clothes_id == 1) {
    image(Clothes1, 0, 0)
  } else if (Clothes_id == 2) {
    image(Clothes2, 0, 0)
  } else if (Clothes_id == 3) {
    image(Clothes3, 0, 0)
  }


  image(Frame, 0, 0);
}

function shuffleClothes() {
  Clothes_id = int(random(1, 4));
}

function shuffleEyes() {
  Eyes_id = int(random(1, 4))
}

function shuffleHair() {
  Hair_id = int(random(1, 4))
}

function keyReleased() {
    if (keyCode === LEFT_ARROW) {
    shuffleEyes();
  }

  if (keyCode === UP_ARROW) {
    shuffleHair();
  }

  if (keyCode === RIGHT_ARROW) {
    shuffleClothes();
  }
  
}